README

Please use Internet Explorer, Microsoft Edge or Firefox.  Chrome will not work!!!
Load up The Broken Future.html
Move using mouse.
Enjoy